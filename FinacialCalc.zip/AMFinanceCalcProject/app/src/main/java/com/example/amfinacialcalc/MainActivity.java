package com.example.amfinacialcalc;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.*;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Double> rpnList = new ArrayList<>(); // Using ArrayList instead of Stack
    private String mode = "RPN"; // Default mode is RPN
    private int fvStep = 0; // Step tracker for future value calculations
    private double presentValue;
    private double interestRate;
    private int years;
    private TextView output;

    private int lpStep = 0;
    private double loanAmount;
    private int loanTerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        output = findViewById(R.id.output);

        Button number1 = findViewById(R.id.num1);
        Button number2 = findViewById(R.id.num2);
        Button number3 = findViewById(R.id.num3);
        Button number4 = findViewById(R.id.num4);
        Button number5 = findViewById(R.id.num5);
        Button number6 = findViewById(R.id.num6);
        Button number7 = findViewById(R.id.num7);
        Button number8 = findViewById(R.id.num8);
        Button number9 = findViewById(R.id.num9);
        Button number0 = findViewById(R.id.num0);

        Button enter = findViewById(R.id.enter);
        Button clear = findViewById(R.id.clear);
        Button fv = findViewById(R.id.fv);
        Button mi = findViewById(R.id.mi);
        Button lp = findViewById(R.id.loanPay);
        Button add = findViewById(R.id.adding);
        Button sub = findViewById(R.id.subtracting);
        Button mult = findViewById(R.id.multiplying);
        Button div = findViewById(R.id.dividing);

        View.OnClickListener numberClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                String buttonText = button.getText().toString();

                if(mode.equals("RPN")){
                    output.append(buttonText + " ");

                } else if ((mode.equals("FV")) || mode.equals("MI") || mode.equals("LP")) {

                    output.append(buttonText);
                }
                rpnList.add(Double.parseDouble(button.getText().toString()));

            }
        };

        number1.setOnClickListener(numberClickListener);
        number2.setOnClickListener(numberClickListener);
        number3.setOnClickListener(numberClickListener);
        number4.setOnClickListener(numberClickListener);
        number5.setOnClickListener(numberClickListener);
        number6.setOnClickListener(numberClickListener);
        number7.setOnClickListener(numberClickListener);
        number8.setOnClickListener(numberClickListener);
        number9.setOnClickListener(numberClickListener);
        number0.setOnClickListener(numberClickListener);

        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mode.equals("RPN")){
                    try{
                        String input = output.getText().toString();
                        double num = Double.parseDouble(input);
                    } catch (NumberFormatException e) {
                            output.setText("Invalid Input");
                    }
                } else if(mode.equals("FV")) {
                    handleFVInput();
                } else if(mode.equals("MI")) {
                    handleMIInput();
                } else if(mode.equals("LP")){
                    handleLPInput();
                }
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rpnList.clear();
                output.setText("");
                mode = "RPN";
                fvStep = 0;
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performOperations("+");
            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performOperations("-");
            }
        });

        mult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performOperations("*");
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performOperations("/");
            }
        });

        fv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mode = "FV";
                output.setText("Enter Present Value: ");
                fvStep =0;

            }
        });

        mi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mode = "MI";
                output.setText("Enter Loan Balance: ");
                fvStep =0;

            }
        });

        lp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mode = "LP";
                output.setText("Enter Loan Amount: ");
                lpStep =0;
            }
        });

    }

    //special finance button methods
    private  void handleFVInput(){
        String input = output.getText().toString().trim();
        try{
            String numericPart = input.replaceAll("[^0-9.]", ""); // i looked this up :\
            if(fvStep == 0){
                presentValue = Double.parseDouble(numericPart);
                output.setText("Enter interest rate: ");
                fvStep = 1;
            } else if (fvStep == 1){
                interestRate = Double.parseDouble(numericPart) /100;
                output.setText("Enter number of years: ");
                fvStep = 2;
            } else if (fvStep == 2) {
                years = Integer.parseInt(numericPart);
                double futureVal = calcFutureVal(presentValue, interestRate, years);
                output.setText("Future Value is:  " + futureVal);
                fvStep = 0;
                mode = "RPN";

            }

        } catch (NumberFormatException e) {
            output.setText("Invalid input. Please enter a valid number.");
        }
    }

    private  void handleMIInput(){
        String input = output.getText().toString().trim();
        try{
            String numericPart = input.replaceAll("[^0-9.]", "");
            if(fvStep == 0){

                presentValue = Double.parseDouble(numericPart);
                output.setText("Enter interest rate: ");
                fvStep = 1;
            } else if (fvStep == 1){
                interestRate = Double.parseDouble(numericPart) /100;
                double monthlyInterest = calcMIVal(presentValue, interestRate);
                output.setText("Monthly Interest is:  " + monthlyInterest);
                fvStep = 0;
                mode = "RPN";
            }

        } catch (NumberFormatException e) {
            output.setText("Invalid input. Please enter a valid number.");
        }
    }

    private  void handleLPInput(){
        String input = output.getText().toString().trim();
        try {
            String numericPart = input.replaceAll("[^0-9.]", "");

            if (lpStep == 0) {
                loanAmount = Double.parseDouble(numericPart);
                output.setText("Enter interest rate: ");
                lpStep = 1;
            } else if (lpStep == 1) {
                interestRate = Double.parseDouble(numericPart) / 100 / 12;
                output.setText("Enter Loan Term (months): ");
                lpStep = 2;
            } else if (lpStep == 2) {
                loanTerm = Integer.parseInt(numericPart);
                double monthlyPayment = calcLoanPayment(loanAmount, interestRate, loanTerm);
                output.setText("Monthly Payment is: " + monthlyPayment);
                lpStep = 0;
                mode = "RPN";
            }
        } catch (NumberFormatException e) {
            output.setText("Invalid input. Please enter a valid number.");
        }
    }

    //calc methods for finacnce
    private  double calcFutureVal(double pv, double rate, int years){
        return Math.round(pv * Math.pow(1 + rate, years) * 100.0) / 100.0;
    }

    private  double calcMIVal(double loanBal, double intRate){
        return Math.round((loanBal * intRate / 12) * 100.0) / 100.0;
    }

    private  double calcLoanPayment(double loanAmount, double monthlyRate, int termMonths){
        if (monthlyRate == 0) {
            return Math.round((loanAmount / termMonths) * 100.0) / 100.0;
        }

        return Math.round((loanAmount * monthlyRate / (1 - Math.pow(1 + monthlyRate, -termMonths))) * 100.0) / 100.0;
    }

    //operations
    private void performOperations(String operator){
        if(rpnList.size() >= 2){
            double b = rpnList.remove(rpnList.size() - 1);
            double a = rpnList.remove(rpnList.size()-1);
            double result = 0.0;

            switch(operator){
                case "+":
                    result = a+b;
                    break;
                case "-":
                    result = a-b;
                    break;
                case "*":
                    result = a*b;
                    break;
                case "/":
                    if(b != 0){
                        result = Math.round((a / b) * 100.0) / 100.0;
                    } else {
                        output.setText("Divide By 0 Error");
                        return;
                    }
                    break;
            }
            rpnList.add(result);
            output.setText(String.valueOf(result + " "));

        } else {
            output.setText("ERROR");
        }
    }

}