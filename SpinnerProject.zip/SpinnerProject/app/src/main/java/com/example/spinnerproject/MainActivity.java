package com.example.spinnerproject;



import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.ArrayList;

//background info:
// this is a musical based on a Odyssey and it's split into Sagas or arcs.
// I've coded 3 of the 9 sagas and each of the songs in each saga
// there are 5 songs in the troy saga and 4 songs in the cyclops and ocean saga.
public class MainActivity extends AppCompatActivity {

    private ArrayList<String> albumList;
    private ArrayList<Integer> albumIcons;
    private ArrayList<Integer> albumIconAlbum1;
    private ArrayList<Integer> albumIconAlbum2;
    private ArrayList<Integer> albumIconAlbum3;
    private ArrayList<ArrayList<String>> songLists;

    private Spinner albumSpinner;
    private Spinner songSpinner;
    private TextView songInfo;
    private TextView songEvents;
    private TextView songLyricsView;

    private  TextView songOpinions;

    private int selectedAlbumIndex = 0;
    private int selectedSongIndex = 0;

    final String COUNT_KEY = "KEY1";

    final String COUNT_KEY2 = "KEY2";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        albumSpinner = findViewById(R.id.album_spinner);
        songSpinner = findViewById(R.id.song_spinner);
        songInfo = findViewById(R.id.song_info);
        songEvents = findViewById(R.id.song_opinion);
        songLyricsView = findViewById(R.id.song_lyrics);
        songOpinions = findViewById(R.id.song_opinions2);

        initializeData(); //call to initalize data cuz there is A LOT

        CustomSpinnerAdapter albumAdapter = new CustomSpinnerAdapter(albumList, albumIcons);
        albumSpinner.setAdapter(albumAdapter);

        if(savedInstanceState != null){
            selectedAlbumIndex = savedInstanceState.getInt(COUNT_KEY);
            selectedSongIndex = savedInstanceState.getInt(COUNT_KEY2);
            updateSongSpinner();
            updateSongInfo();
        }

        albumSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedAlbumIndex = position;

                if(selectedSongIndex > 3 && selectedAlbumIndex != 0){
                    selectedSongIndex = 3;
                }

                updateSongSpinner();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        songSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSongIndex = position;

                if(selectedSongIndex > 3 && selectedAlbumIndex != 0){
                    selectedSongIndex = 3;
                }

                updateSongInfo();


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        albumSpinner.setSelection(selectedAlbumIndex);
        updateSongSpinner();
    }

    private void initializeData() {
        albumList = new ArrayList<>();
        albumIcons = new ArrayList<>();
        songLists = new ArrayList<>();
        albumIconAlbum1 = new ArrayList<>();
        albumIconAlbum2 = new ArrayList<>();
        albumIconAlbum3 = new ArrayList<>();

        albumList.add("Troy");
        albumList.add("Cyclops");
        albumList.add("Ocean");

        //these icons r for the second spinner's images, it'll show what saga each song is in
        albumIconAlbum1.add(R.drawable.thehorse);
        albumIconAlbum1.add(R.drawable.justaman);
        albumIconAlbum1.add(R.drawable.fullspeedahead);
        albumIconAlbum1.add(R.drawable.openarms);
        albumIconAlbum1.add(R.drawable.warriorofthemind);

        albumIconAlbum2.add(R.drawable.polyphemus);
        albumIconAlbum2.add(R.drawable.survive);
        albumIconAlbum2.add(R.drawable.rememberthem);
        albumIconAlbum2.add(R.drawable.mygoodbye);

        albumIconAlbum3.add(R.drawable.storm);
        albumIconAlbum3.add(R.drawable.luckrunsout);
        albumIconAlbum3.add(R.drawable.keepurfriends);
        albumIconAlbum3.add(R.drawable.ruthlessness);

        //icons
        albumIcons.add(R.drawable.troy);
        albumIcons.add(R.drawable.cyclops);
        albumIcons.add(R.drawable.ocean);

        //songs per album
        ArrayList<String> album1Songs = new ArrayList<>();
        album1Songs.add("The Horse & The Infant");
        album1Songs.add("Just a Man");
        album1Songs.add("Full Speed Ahead");
        album1Songs.add("Open Arms");
        album1Songs.add("Warrior of the Mind");
        songLists.add(album1Songs);

        ArrayList<String> album2Songs = new ArrayList<>();
        album2Songs.add("Polyphemus");
        album2Songs.add("Survive");
        album2Songs.add("Remember Them");
        album2Songs.add("My Goodbye");
        songLists.add(album2Songs);

        ArrayList<String> album3Songs = new ArrayList<>();
        album3Songs.add("Storm");
        album3Songs.add("Luck Runs Out");
        album3Songs.add("Keep Your Friends Close");
        album3Songs.add("Ruthlessness");
        songLists.add(album3Songs);


    }

    //updates the second spinner based on what album is selected
    private void updateSongSpinner() {
        CustomSpinnerAdapter songAdapter = null;
        ArrayList<String> songs = songLists.get(selectedAlbumIndex);
        if(selectedAlbumIndex == 0) {
            songAdapter = new CustomSpinnerAdapter(songs, albumIconAlbum1);
        }
        else if(selectedAlbumIndex == 1) {
            songAdapter = new CustomSpinnerAdapter(songs, albumIconAlbum2);
        }
       else  if(selectedAlbumIndex == 2) {
            songAdapter = new CustomSpinnerAdapter(songs, albumIconAlbum3);
        }
        songSpinner.setAdapter(songAdapter);
        songSpinner.setSelection(selectedSongIndex);
    }

    @SuppressLint("SetTextI18n")
    private void updateSongInfo() {
        String song = songLists.get(selectedAlbumIndex).get(selectedSongIndex);
//troy
       if(selectedAlbumIndex == 0 && selectedSongIndex == 0){
           songInfo.setText("Selected Song: " + song);
           songLyricsView.setText("[ODYSSEUS, (ZEUS)]\n" +
                   "I could raise him as my own (He will burn your house and throne)\n" +
                   "Or send him far away from home (He'll find you wherever you go)\n" +
                   "Make sure his past is never known (The gods will make it known)\n" +
                   "I'd rather bleed for ya, down on my knees for ya (He's bringing you down on your knees for ya)\n" +
                   "I'm begging please Oh, this is the will of the gods\n" +
                   "Please don't make me do this, don't make me do this\n" +
                   "[ZEUS]\n" +
                   "The blood on your hands is something you won't lose\n" +
                   "[ALL]\n" +
                   "All you can choose is whose");
           if (songEvents != null && songOpinions != null) {
               songEvents.setText("Odysseus, who longs to return to his wife and son, raids Troy and Zeus gives him an ultimatium to kill the Trojan son of Prince Hector or risk his family dying at the son's hands.");
               songOpinions.setText("OPINION: This is a very strong opening song and how it introduces the main theme of the show in the highest stakes possible is amazing. ");
           }
       }
        else if(selectedAlbumIndex == 0 && selectedSongIndex == 1){
            songInfo.setText("Selected Song: " + song);
           songLyricsView.setText("But when does a comet become a meteor?\n" +
                   "When does a candle become a blaze?\n" +
                   "Whеn does a man become a monster?\n" +
                   "When does a ripple become a tidal wave?\n" +
                   "When does the reason become the blame?\n" +
                   "When does a man become a monster?" +
                   "Forgive Me" +
                   "I'm just a man\n");
            if (songEvents != null && songOpinions != null) {
                songEvents.setText("Odysseus yeets Astyanax off a tower. Before that he sings about returning home and the guilt he feels over he lives he has taken.");
                songOpinions.setText("OPINION: Arguably the most emotional song, you really feel for Ody and his decision making and you're left holding your breath pondering the decision he made.");
            }
        }
       else if(selectedAlbumIndex == 0 && selectedSongIndex == 2){
           songInfo.setText("Selected Song: " + song);
           songLyricsView.setText("Full speed ahead\n" +
                   "We're up, we're off, and away we go\n" +
                   "We're up, we're off, and away we go\n" +
                   "Full speed ahead\n" +
                   "We're up, we're off, and away we go\n" +
                   "We're up, we're off, and a-\n" +
                   "Full speed ahead");
           if (songEvents != null && songOpinions != null) {
               songEvents.setText("Eurylochus informs Odysseus that his 600 men need food while sailing across the sea, Polites, using birds, finds an island and Odysseus and Polites head to scout the island");
                songOpinions.setText("OPINION: This song gives introductions to vital characters in the story. I like the main melody and how the characters are introduced.");
           }
       }
       else if(selectedAlbumIndex == 0 && selectedSongIndex == 3){
           songInfo.setText("Selected Song: " + song);
           songLyricsView.setText("[POLITES]\n" +
                   "This life is amazing when you greet it with open arms\n" +
                   "I see in your face, there is so much guilt inside your heart\n" +
                   "So why not replace it and light up the world\n" +
                   "Here's how to start:\n" +
                   "Greet the world with open arms\n" +
                   "Greet the world with open arms\n" +
                   "[ODYSSEUS]\n" +
                   "Greet the world with open arms\n" +
                   "[POLITES]\n" +
                   "You can relax, my friend");
           if (songEvents != null && songOpinions != null) {
               songEvents.setText("Polites tries convincing Odysseus to live life with open arms and show others a bit more trust. Also the lotus eaters are in this song.");
               songOpinions.setText("OPINION: My least favorite in the Troy saga doesn't mean it isn't good. I love its message and the Winions, I just enjoy the other songs more.");
           }
       }
       else if(selectedAlbumIndex == 0 && selectedSongIndex == 4){
           songInfo.setText("Selected Song: " + song);
           songLyricsView.setText("[ODYSSEUS, ENSEMBLE]\n" +
                   "Nah, don't be modest\n" +
                   "I know you're a goddess\n" +
                   "So let's be honest\n" +
                   "You are Athena (Athena)\n" +
                   "Badass in the arena\n" +
                   "Unmatched, witty, and queen of\n" +
                   "The best strategies we've seen");
           if (songEvents != null && songOpinions != null) {
               songEvents.setText("Athena reminds Odysseus that he must close off his heart and follow her teachers as he is a Warrior of the Mind. This song is told through a flashback where Athena & Ody first meet." );
               songOpinions.setText("OPINION: This is the best song in the Troy saga and I love Athena and her voice actor so muvch. She sent me a personalized signed art card and letter so this song and character are very special to me.");
           }
       }
       //Cyclops


       else if(selectedAlbumIndex == 1 && selectedSongIndex == 0){
           songInfo.setText("Selected Song: " + song);
            songLyricsView.setText("[ODYSSEUS]\n" +
                    "Have a drink\n" +
                    "One sip and you'll understand\n" +
                    "The power that's in your hands\n" +
                    "A wine so fresh\n" +
                    "You'd never wanna eat human flesh again\n" +
                    "Then we shall be on our way\n" +
                    "No bloodshed in here today\n" +
                    "A trade, you see?\n" +
                    "A gift from you and a gift from me");
            if (songEvents != null && songOpinions != null) {
               songEvents.setText("The crew unknowingly kills the Cyclops, Polyphemus' favorite sheep. Odysseus must now bargain for their lives by offering a sip of lotus-infused wine, whcih take sover your mind. He tells Polyphemus that his name is Nobody as well." );
               songOpinions.setText("OPINION: This song is the weakest in the saga serving as a introduction to Polyphemus and setting up the boss battle in later songs. I love how Poly's best friend is a sheep lol.");
           }
       }
       else if(selectedAlbumIndex == 1 && selectedSongIndex == 1){
           songInfo.setText("Selected Song: " + song);
            songLyricsView.setText("Six hundred lives at stake\n" +
                    "It's just one life to take\n" +
                    "And when we kill him then our journey’s over\n" +
                    "No dying on me now\n" +
                    "Defeat is not allowed\n" +
                    "We must live through this day so\n" +
                    "Fight, fight, fight");
           if (songEvents != null && songOpinions != null) {
               songEvents.setText("Odysseus leads his crew into battle against Polyphemus. they are doing well at first until Polyphemus retreats into his cave, pulls out a club, and turns Polites into a pancake. Polyphemus proceeds to unalive 13 more men. " );
               songOpinions.setText("OPINION: I legit can't listen to this song without nearly dying inside cuz I love Polites and he DIES. LIKE OMG JAY (the creator of the musical) I JUST WANT HAPPINESS GOD!");
           }
       }
       else if(selectedAlbumIndex == 1 && selectedSongIndex == 2){
           songInfo.setText("Selected Song: " + song);
            songLyricsView.setText("[ODYSSEUS]\n" +
                    "Hey, Cyclops!\n" +
                    "When we met, I led with peace\n" +
                    "While you fed your inner beast\n" +
                    "But my comrades will not die in vain\n" +
                    "Remember them\n" +
                    "The next time that you dare choose not to spare\n" +
                    "Remember them\n" +
                    "Remember us\n" +
                    "Remember me\n" +
                    "I'm the reigning king of Ithaca\n" +
                    "I am neither man nor mythical\n" +
                    "I am your darkest moment\n" +
                    "I am the infamous...\n" +
                    "ODYSSEUS!!!");
           if (songEvents != null && songOpinions != null) {
               songEvents.setText("The lotus wine Odysseus gave Polyphemus kicks and he passes out. Odysseus decides to avenge his best friend and fallen crewmates by stabbing out Polyphemus' eye using his club. Athen tells Ody to finish the job but he refuses and proceeds to reveal his name to Polyphemus, who smiles with blood dripping out his eye." );
               songOpinions.setText("OPINION: This is my favorite song in the saga, and I LOVE the ending. But, Ody is so dumb in this song like wow dude, you just revealed your name, address, and social security num-");
           }
       }
       else if(selectedAlbumIndex == 1 && selectedSongIndex == 3){
           songInfo.setText("Selected Song: " + song);
            songLyricsView.setText("[ODYSSEUS]\n" +
                    "At least I know what I'm fighting for\n" +
                    "While you're fighting to be known\n" +
                    "Since you claim you're so much wiser\n" +
                    "Why's your life spent all alone?\n" +
                    "You're alone\n" +
                    "[ATHENA]\n" +
                    "One day, you'll hear what I'm saying\n" +
                    "One day, you might understand\n" +
                    "One day, but not today, for after all you're\n" +
                    "[ENSEMBLE]\n" +
                    "Just a man");
           if (songEvents != null && songOpinions != null) {
               songEvents.setText("Athena & Ody breakup, platonically. She scolds Ody for sparing Polyphemus' life and not listening to her. She abandons being his mentor and leaves him with her final goodbye." );
               songOpinions.setText("OPINION: Athena my pookie :c This song is also so sad and it's too sad to listen to but they make up, trust.");
           }
       }

       //Ocean


       else if(selectedAlbumIndex == 2 && selectedSongIndex == 0){
           songInfo.setText("Selected Song: " + song);
            songLyricsView.setText("This storm's our final fight\n" +
                    "There's no time to die, comrades Sir!!!\n" +
                    "Brace for a storm\n" +
                    "Storm\n" +
                    "The likes of which we've never seen before\n" +
                    "Brace for a storm\n" +
                    "Storm\n" +
                    "With home so close, we must keep pushing forward\n" +
                    "Full speed ahead\n" +
                    "Head towards the island but avoid the crashing waves\n" +
                    "Tread where the tide is flat and then you will be savеd");
           if (songEvents != null && songOpinions != null) {
               songEvents.setText("Odysseus and his crew face an impenetrable storm. Ody ponders if it was sent by the Gods or a force of nature. They must survive and make it out alive before their ship capsizes.");
               songOpinions.setText("OPINION: I LOVE THE INSTRUMENTALS IN THIS SONG, the vocals mixed with the brass ensemble and epic guitar make this song exciting and feel like your gonna drown and die in the storm.");
           }
       }
       else if(selectedAlbumIndex == 2 && selectedSongIndex == 1){
           songInfo.setText("Selected Song: " + song);
            songLyricsView.setText("[EURYLOCHUS & CREW]\n" +
                    "Yes, but how much longer til your luck runs out?\n" +
                    "How much longer til the show goes south?\n" +
                    "How much longer til we all fall down?\n" +
                    "You rely on wit, and people die on it, woah");
           if (songEvents != null && songOpinions != null) {
               songEvents.setText("Odysseus and Eurylochus argue as to whether or not Odysseus should seek help from the wind god, Aeolus. Odysseus scolds Eurylochus for creating doubt in his crew leaving Eury and the crew slightly pissed off." );
               songOpinions.setText("OPINION: The foreshadowing this song has in the next song and future songs is so heartbreaking. I love this look into the crew's opinions and how Ody is creating doubt that will come back to bite him.");
           }
       }
       else if(selectedAlbumIndex == 2 && selectedSongIndex == 2){
           songInfo.setText("Selected Song: " + song);
            songLyricsView.setText("[AEOLUS, WINIONS]\n" +
                    "Ha ha ha\n" +
                    "Keep your friends close as your enemiеs closer\n" +
                    "Never rеally know who you can trust\n" +
                    "If they wanna get the bag open, you gotta say \"no, sir\"\n" +
                    "Sometimes killing is a must\n" +
                    "[ODYSSEUS]\n" +
                    "What?");
           if (songEvents != null && songOpinions != null) {
               songEvents.setText("Odysseus asks Aeolus for help getting through the storm. Aeolus, surrounded by Winions, gives Ody a Bag that holds the storm. However, the Winions convince the crew that there is gold in the bag. After 9 days of staying awake, Ody hallucinates his wife and son the latter of whom tells him someone has opened the win bag. Ody awakens to the storm carrying his crew off the coast of Ithaca to the land of the giants, home of Poseidon. ");
               songOpinions.setText("OPINION: This is a big 'plot' song and it kinda hurts it's overall melodic structure. I still love the events that happen in this song and the winions have my heart. ");
           }
       }
       else if(selectedAlbumIndex == 2 && selectedSongIndex == 3){
           songInfo.setText("Selected Song: " + song);
            songLyricsView.setText("[POSEIDON, LAESTRYGONIANS]\n" +
                    "I'm left without a choice\n" +
                    "And without a doubt\n" +
                    "Guess the pack of wolves is swimming with the shark now\n" +
                    "I've gotta make you bleed\n" +
                    "I need to see you drown\n" +
                    "But before you go, I need to make you learn how\n" +
                    "Ruthlessness is mercy upon ourselves");
           if (songEvents != null && songOpinions != null) {
               songEvents.setText("Poseidon shows up to take revenge on Odysseusand his crew for hurting, and more importantly sparing, his son, Polyphemus. Poseidon sings that being ruthless is merciful. He then kills 543 men leavng Odysseus with one ship and 43 left under his commands. Ody opens the wind bag and uses it to escape Poseidon leaving him to fight another day.");
               songOpinions.setText("OPINION: POSEIDON IS SO COOL MAN. I know he's kind of an asshole but I CAN FIX HIM. The amount of karma Ody receives in this song is a bit much but yk, POSEIDON! yay!");
           }
       }



    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(COUNT_KEY, selectedAlbumIndex);
        outState.putInt(COUNT_KEY2, selectedSongIndex);
    }

    class CustomSpinnerAdapter extends BaseAdapter { //baseadapter according to chatgpt is better for images and text
        private ArrayList<String> items;
        private ArrayList<Integer> icons;


       public CustomSpinnerAdapter(ArrayList<String> items, ArrayList<Integer> icons) { //standard base class
            this.items = items;
            this.icons = icons;
        }



//get methods
        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        //overrided get view
        @Override
        public View getView(int i, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.spinner_item, parent, false);
            }

            ImageView icon = convertView.findViewById(R.id.item_icon);
            TextView text = convertView.findViewById(R.id.item_text);

            text.setText(items.get(i));

            if (!icons.isEmpty() && i < icons.size()) {
                icon.setImageResource(icons.get(i));
                icon.setVisibility(View.VISIBLE);
            } else {
                icon.setVisibility(View.INVISIBLE);
            }

            return convertView;
        }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            return super.getDropDownView(position, convertView, parent);
        }
    }
}