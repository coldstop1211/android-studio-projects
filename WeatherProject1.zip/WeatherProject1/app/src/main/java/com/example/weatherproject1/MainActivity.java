package com.example.weatherproject1;

import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {

    private TextView weatherDescription, temperature, time, cityLoc;
    private ImageView weatherIcon;
    private SeekBar seekBar;
    private EditText zipCodeInput;
    private List<WeatherEvent> weatherEvents;
    private String zipcode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Log.d("TAG_UI", "e");

        weatherDescription = findViewById(R.id.temperature);
        temperature = findViewById(R.id.weatherDescription);
        time = findViewById(R.id.date_and_time);
        weatherIcon = findViewById(R.id.imageView);
        seekBar = findViewById(R.id.seekBar);
        zipCodeInput = findViewById(R.id.zipcode_input_actual);
        cityLoc = findViewById(R.id.city_location);

        weatherEvents = new ArrayList<>();


        ConstraintLayout constraintLayout = findViewById(R.id.main);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(10);
        animationDrawable.setExitFadeDuration(5000);
        animationDrawable.start();





       zipCodeInput.addTextChangedListener(new TextWatcher() {
           @Override
           public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

           }

           @Override
           public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if(charSequence.length() == 5){
                zipcode = charSequence.toString();
                fetchData(zipcode);
            }
           }

           @Override
           public void afterTextChanged(Editable editable) {

           }
       });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                if (progress < weatherEvents.size()) {
                    WeatherEvent event = weatherEvents.get(progress);
                    updateUI(event);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }

    private void fetchData(String zipcode){
        AsyncThread asyncThread = new AsyncThread();
        asyncThread.execute(zipcode);
    }

    private void updateUI(WeatherEvent event){
        int temp = (int) Double.parseDouble(event.getTemperature());
        time.setText(event.getTime());
        temperature.setText(temp + "°F");
        weatherDescription.setText(event.getDescription());
        cityLoc.setText(event.getCityname());

        if (event.getDescription().contains("clear")) {
            weatherIcon.setImageResource(R.drawable.elphie_sunny);
        } else if (event.getDescription().contains("cloud")) {
            weatherIcon.setImageResource(R.drawable.glinda_cloudy);
        } else if (event.getDescription().contains("rain")) {
            weatherIcon.setImageResource(R.drawable.elphie_rainy);
        } else if (event.getDescription().contains("snow")) {
            weatherIcon.setImageResource(R.drawable.elphie_snow);
        } else {
            weatherIcon.setImageResource(R.drawable.wicked_logo);
        }
    }

    public class AsyncThread extends AsyncTask<String, Void, List<WeatherEvent>> { //this modified header allows the task to take in a String and output a List<weatherEvent> as the result

        @Override
        protected List<WeatherEvent> doInBackground(String... params) {
            String zipcode = params[0]; //this recieves the first parameter which is the zipcode that was passed to the task
            String apiUrl = "https://api.openweathermap.org/data/2.5/forecast?zip=" + zipcode + "&units=imperial&APPID=b17b29462a7feb542d8a4cf2782e3f83";
            List<WeatherEvent> events = new ArrayList<>();
            try {
                URL url = new URL(apiUrl);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder result = new StringBuilder();
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    result.append(line);
                }

                JSONObject jsonObject = new JSONObject(result.toString());
                JSONArray list = jsonObject.getJSONArray("list");
                String cityName = jsonObject.getJSONObject("city").getString("name");


                for (int i = 0; i < 6; i++) {
                    JSONObject eventObject = list.getJSONObject(i);
                    String eventTime = eventObject.getString("dt");
                    String eventTemperature = eventObject.getJSONObject("main").getString("temp");
                    String eventDescription = eventObject.getJSONArray("weather").getJSONObject(0).getString("description");


                    long unixTime = Long.parseLong(eventTime);
                    Date date = new Date(unixTime*1000);
                    SimpleDateFormat sdf = new SimpleDateFormat("EEE,  d MMM yyyy,  HH:mm:ss");
                    sdf.setTimeZone(TimeZone.getTimeZone("America/New_York"));
                    String formattedDate = sdf.format(date);

                    events.add(new WeatherEvent(formattedDate, eventTemperature, eventDescription, cityName));
                }


            } catch (IOException | JSONException e) {
                e.printStackTrace();
                Log.e("WeatherApp", "Error fetching data: " + e.getMessage());
            }

            return events;
        }

        @Override
        protected void onPostExecute(List<WeatherEvent> events) {

            if(events == null || events.isEmpty()){
                Toast.makeText(MainActivity.this, "Failed to fetch data", Toast.LENGTH_SHORT).show();
            } else {
                weatherEvents = events;
                updateUI(weatherEvents.get(0));
            }

        }
    }
}//class

 class WeatherEvent { //its easier to make a class as it contains all the info you need
    private  String time;
    private  String temperature;
    private  String description;
    private  String cityname;

    public WeatherEvent(String time, String temperature, String description, String cityname) {
        this.time = time;
        this.temperature = temperature;
        this.description = description;
        this.cityname = cityname;
    }

    public String getTime() {
        return time;
    }

    public String getTemperature() {
        return temperature;
    }

    public String getDescription() {
        return description;
    }

    public  String getCityname(){
        return cityname;
    }
}


