package com.example.gpsdemo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private LocationManager locationManager;
    private MyLocationListener myLocationListener;
    private Location lastLocation, mostVisitedLocation;
    private float totalDistance = 0;
    private boolean trackingStarted = false;
    private long startTime;
    private long maxTimeSpent = 0, lastLocationTime = 0;
    private final List<Location> locationHistory = new ArrayList<>();
    private final List<Long> timeAtLocations = new ArrayList<>();
    private TextView tv, distanceView, addressView, timeView, mostVisited;
    private final HashMap<String, Long> locationTimeMap = new HashMap<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        myLocationListener = new MyLocationListener();

        tv = findViewById(R.id.location);
        distanceView = findViewById(R.id.distance);
        addressView = findViewById(R.id.address);
        timeView = findViewById(R.id.timeSpent);
        mostVisited = findViewById(R.id.mvl);

        checkLocationPermission();

    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            requestLocationUpdates();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                requestLocationUpdates();
            }
        }
    }

    private void requestLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 2, myLocationListener);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        locationManager.removeUpdates(myLocationListener);
    }

    private class MyLocationListener implements LocationListener {
        @SuppressLint("SetTextI18n")
        @Override
        public void onLocationChanged(@NonNull Location location) {

            //get lat and long
            double latitude = Math.round(location.getLatitude() * 10000.0) / 10000.0;
            double longitude = Math.round(location.getLongitude() * 10000.0) / 10000.0;

            Log.d("TAG", latitude + "");
            Log.d("TAG", longitude + "");

            tv.setText("Latitute: " + latitude + "\nLongitude: " + longitude);
            Geocoder geocoder = new Geocoder(MainActivity.this, Locale.US);

            //location u spend the most time at
            if (lastLocation != null) {
                long currentTime = SystemClock.elapsedRealtime();
                long timeSpent1 = currentTime - lastLocationTime;

                String lastLocationKey = lastLocation.getLatitude() + "," + lastLocation.getLongitude();

                if (locationTimeMap.containsKey(lastLocationKey)) {
                    locationTimeMap.put(lastLocationKey, locationTimeMap.get(lastLocationKey) + timeSpent1);
                } else {
                    locationTimeMap.put(lastLocationKey, timeSpent1);
                }

                if (locationTimeMap.get(lastLocationKey) > maxTimeSpent) {
                    maxTimeSpent = locationTimeMap.get(lastLocationKey);
                    mostVisitedLocation = lastLocation;
                }

                if (mostVisitedLocation != null) {
                    try {
                        List<Address> addresses = geocoder.getFromLocation(
                                mostVisitedLocation.getLatitude(),
                                mostVisitedLocation.getLongitude(),
                                1
                        );
                        if (!addresses.isEmpty()) {
                            mostVisited.setText("Most visited address: " + addresses.get(0).getAddressLine(0));
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

// Update last location time
            lastLocationTime = SystemClock.elapsedRealtime();



            //geocoder code/addresses
            try {
                List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
                if (addresses != null && !addresses.isEmpty()) {
                    Address address = addresses.get(0);
                    addressView.setText("Address: " + address.getAddressLine(0));
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            //distance traveled code
            if(lastLocation != null){
                    float distance = lastLocation.distanceTo(location);
                    totalDistance += distance;
                    distanceView.setText("Total distance: " + (Math.round((totalDistance* 0.000621371192)*1000.0)/1000.0) + " miles");
                    long elapsedTIme = SystemClock.elapsedRealtime() - startTime;
                    if(elapsedTIme > 5000){
                        trackingStarted = true;
                    }
            } else {
                startTime = SystemClock.elapsedRealtime();
            }
            lastLocation = location;

            //track time
            if (!locationHistory.isEmpty()) {
                long timeSpent = SystemClock.elapsedRealtime() - timeAtLocations.get(timeAtLocations.size() - 1);
                timeView.setText("Time Spent: " + (timeSpent / 1000) + " sec");
            }
            locationHistory.add(location);
            timeAtLocations.add(SystemClock.elapsedRealtime());

        }
    }
}